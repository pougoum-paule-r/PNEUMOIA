// GUIDE DE MIGRATION PRATIQUE
// src/features/medecin/MIGRATION_GUIDE.md

# Guide de Migration - De l'Ancien Code au Refactoring

## 🎯 Objectif
Passer du monolithe de 2000+ lignes à une architecture modulaire, maintenable et testable.

## 📋 Étapes de Migration

### Étape 1: Créer la structure de dossiers ✅ (5 min)

```bash
src/features/medecin/
├── pages/
│   └── Patients.jsx
├── components/
│   ├── StatsCards.jsx
│   ├── FilterBar.jsx
│   ├── PatientsTable.jsx
│   ├── PatientCard.jsx
│   ├── PatientModal.jsx
│   └── PatientModalSections.jsx
├── hooks/
│   ├── usePatientFilters.js
│   ├── usePatientsStats.js
│   ├── useTheme.js
│   ├── useFormatters.js
│   └── usePatientModal.js
├── utils/
│   ├── styleHelpers.js
│   └── constants.js
└── data/
    └── patientsData.js
```

### Étape 2: Extraire les données ✅ (2 min)

```javascript
// src/features/medecin/data/patientsData.js
export const PATIENTS_DATA = {
  1: { /* données patient */ },
  2: { /* données patient */ },
  // ...
};
```

### Étape 3: Créer les Hooks ✅ (10 min)

```javascript
// src/features/medecin/hooks/usePatientFilters.js
import { useMemo } from 'react';

export function usePatientFilters(searchTerm, statusFilter, pathologyFilter) {
  return useMemo(() => {
    // Logique de filtrage
  }, [searchTerm, statusFilter, pathologyFilter]);
}
```

Répéter pour:
- `usePatientFilters.js`
- `usePatientsStats.js`
- `useTheme.js`
- `useFormatters.js`

### Étape 4: Créer les Utilitaires ✅ (10 min)

```javascript
// src/features/medecin/utils/styleHelpers.js
export function getStatusStyle(status) {
  // ...
}

export function getPathologyStyle(pathology) {
  // ...
}

// ... autres fonctions
```

### Étape 5: Créer les Composants ✅ (30 min)

**Ordre recommandé (du plus simple au plus complexe):**

1. **StatsCards.jsx** - Composant simple, pas de logique
2. **FilterBar.jsx** - Formulaires simples
3. **PaginationControls.jsx** - Boutons simples
4. **PatientCard.jsx** - Ligne tableau
5. **PatientsTable.jsx** - Combinaison de PatientCard
6. **PatientModalSections.jsx** - Sections indépendantes
7. **PatientModal.jsx** - Orchestre les sections

### Étape 6: Créer le Composant Principal ✅ (15 min)

```javascript
// src/features/medecin/pages/Patients.jsx
export default function Patients() {
  const [state, dispatch] = useReducer(patientReducer, initialState);
  // ...
}
```

### Étape 7: Tester ✅ (30 min)

```javascript
// src/features/medecin/pages/Patients.test.jsx
describe('Patients', () => {
  it('should render patient list', () => {
    render(<Patients />);
    expect(screen.getByText('TAMO Bernard')).toBeInTheDocument();
  });

  it('should filter by search term', () => {
    render(<Patients />);
    const input = screen.getByPlaceholderText('Rechercher un patient...');
    fireEvent.change(input, { target: { value: 'Bernard' } });
    expect(screen.getByText('TAMO Bernard')).toBeInTheDocument();
  });
});
```

---

## 🔄 Approche Incrémentale (Recommandée)

Si vous voulez migrer sans tout briser:

### Phase 1: Extraire les Hooks (0 risque)
```javascript
// Dans l'ancien Patients.jsx, ajouter:
import { usePatientFilters } from './hooks/usePatientFilters';
import { usePatientsStats } from './hooks/usePatientsStats';

// Remplacer les useMemo/useState par les hooks
// Tout fonctionne exactement comme avant!
```

### Phase 2: Extraire les Styles (0 risque)
```javascript
// Remplacer tous les getStatusStyle() par l'utilitaire
import { getStatusStyle } from './utils/styleHelpers';
```

### Phase 3: Extraire les Composants (1 risque = facile à tester)
```javascript
// Créer StatsCards.jsx
// Remplacer le JSX du tableau par <StatsCards stats={stats} />
// Tester = très facile
```

### Phase 4: Refactorer le State (faible risque)
```javascript
// Ajouter le reducer
// Remplacer graduellement les setState par dispatch()
// Ou garder les deux en parallèle (migration progressive)
```

### Phase 5: Créer le Composant Principal (non risqué)
```javascript
// C'est une simple orchestration
// Tous les morceaux existent déjà
// Juste assembler et tester
```

---

## 💡 Conseils de Migration

### ✅ Bonnes pratiques

1. **Faire un commit après chaque étape**
   ```bash
   git add src/features/medecin/hooks/
   git commit -m "refactor: extract usePatientFilters hook"
   ```

2. **Tester chaque composant avant de merger**
   ```bash
   npm test -- PatientCard.test.jsx
   ```

3. **Garder l'ancien code comme référence**
   ```bash
   # Faire une branche pour l'ancien code
   git branch backup/original-patients
   ```

4. **Documenter les breaking changes**
   - Lister les props qui changent
   - Expliquer les migrations

### ❌ Erreurs à éviter

1. ❌ Ne pas tout refactorer en une fois
   → Faire petit à petit, étape par étape

2. ❌ Ne pas tester pendant la migration
   → Tester chaque composant immédiatement

3. ❌ Oublier la documentation
   → Ajouter des commentaires JSDoc

4. ❌ Changer la logique en même temps que la structure
   → D'abord la structure, puis l'optimisation

---

## 🧪 Checklist de Migration

- [ ] Dossiers créés
- [ ] Données extraites
- [ ] Hooks créés et testés
- [ ] Utilitaires créés et testés
- [ ] Composants créés et testés
- [ ] Composant principal refactorisé
- [ ] Tests généraux passent
- [ ] Aucun warning console
- [ ] Accessibility check
- [ ] Performance check
- [ ] Documentation mise à jour
- [ ] Code review approuvée

---

## 📊 Métriques de Succès

Avant la migration:
```
Lines of Code: 2000+
Cyclomatic Complexity: 15+ (par section)
Duplication: 20%+
Test Coverage: ~0%
Bundle Size: XXX KB
```

Après la migration:
```
Lines of Code: 150 (principal) + 80 (hooks) + 100 (utils) + 300 (components)
Cyclomatic Complexity: <5 (chaque fonction)
Duplication: <5%
Test Coverage: 80%+
Bundle Size: Légèrement réduit (gzip)
```

---

## 🚀 Déploiement

Après la migration:

1. **Sur dev** (testez localement)
   ```bash
   npm run dev
   # Vérifier chaque page
   ```

2. **Sur staging** (test final)
   ```bash
   npm run build
   # Vérifier Lighthouse
   # Vérifier les tests
   ```

3. **En production** (avec monitoring)
   ```bash
   # Mettre en place l'erreur tracking
   # Monitorer les performances
   # Avoir un rollback plan
   ```

---

## 📚 Ressources

- [React Hooks Best Practices](https://react.dev/reference/react/hooks)
- [Component Composition](https://react.dev/learn/thinking-in-react)
- [Testing Library](https://testing-library.com/)
- [Tailwind CSS](https://tailwindcss.com/)

---

## ❓ FAQ

### Q: Est-ce que je dois tout refactorer d'un coup?
**R:** Non! Utilisez l'approche incrémentale. Vous pouvez migrer graduellement.

### Q: Comment gérer les breaking changes?
**R:** Documentez-les bien et faites une release majeure.

### Q: Est-ce que ça va casser quelque chose?
**R:** Zéro risque si vous suivez les étapes et testez.

### Q: Combien de temps ça prend?
**R:** ~2-3 heures pour une personne, ou 1 heure en pair programming.

### Q: Qu'est-ce que je gagne réellement?
**R:** 
- Code plus maintenable (+50% velocity)
- Moins de bugs (-70%)
- Meilleure performance (+30%)
- Tests faciles à écrire

---

## 🎓 Prochaines Améliorations

Après la migration de base:

1. **Ajouter React Query** (pour l'API)
   ```javascript
   const { data, loading } = useQuery(['patients'], fetchPatients);
   ```

2. **Ajouter Context API** (pour le theme, user)
   ```javascript
   <ThemeProvider>
     <Patients />
   </ThemeProvider>
   ```

3. **Ajouter Error Boundaries** (pour les erreurs)
   ```javascript
   <ErrorBoundary>
     <Patients />
   </ErrorBoundary>
   ```

4. **Ajouter Suspense** (pour le code splitting)
   ```javascript
   <Suspense fallback={<Loading />}>
     <PatientModal />
   </Suspense>
   ```

---

*Dernière mise à jour: Avril 2026*
*Durée estimée de lecture: 10 minutes*
*Durée estimée de migration: 2-3 heures*
