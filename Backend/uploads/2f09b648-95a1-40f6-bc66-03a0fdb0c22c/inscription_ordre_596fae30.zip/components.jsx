// src/features/medecin/components/StatsCards.jsx
import { motion } from 'framer-motion';
import {
  Users, Stethoscope, AlertCircle, Share2
} from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 300, damping: 24 },
  },
};

export function StatsCards({ stats, totalPatients }) {
  const cards = [
    {
      label: 'Total patients',
      value: totalPatients,
      trend: '+12 ce trimestre',
      icon: Users,
      color: 'blue',
    },
    {
      label: 'Consultés ce mois',
      value: stats.consultationsMonth,
      trend: '+5 vs février',
      icon: Stethoscope,
      color: 'emerald',
    },
    {
      label: 'Suivis urgents',
      value: stats.urgent,
      trend: 'Action requise',
      icon: AlertCircle,
      color: 'rose',
    },
    {
      label: 'Dossiers partagés',
      value: stats.shared,
      trend: 'Actifs',
      icon: Share2,
      color: 'indigo',
    },
  ];

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-2 lg:grid-cols-4 gap-4"
    >
      {cards.map((card, idx) => {
        const Icon = card.icon;
        const colorMap = {
          blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
          emerald:
            'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400',
          rose: 'bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400',
          indigo:
            'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400',
        };

        return (
          <motion.div
            key={idx}
            variants={itemVariants}
            whileHover={{ y: -2 }}
            className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm p-5"
          >
            <div className="flex items-center justify-between">
              <div className={`p-2 rounded-lg ${colorMap[card.color]}`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                {card.trend}
              </span>
            </div>
            <div className="mt-3">
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {card.value}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {card.label}
              </p>
            </div>
          </motion.div>
        );
      })}
    </motion.div>
  );
}

// src/features/medecin/components/FilterBar.jsx
import { Search, Filter } from 'lucide-react';
import { PATHOLOGIES } from '../utils/constants';

export function FilterBar({
  searchTerm,
  statusFilter,
  pathologyFilter,
  totalPatients,
  urgentCount,
  onSearchChange,
  onStatusFilterChange,
  onPathologyFilterChange,
}) {
  return (
    <div className="flex flex-col lg:flex-row gap-4">
      {/* Recherche */}
      <div className="flex-1 relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Rechercher un patient..."
          className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          aria-label="Rechercher patients"
        />
      </div>

      {/* Filtres */}
      <div className="flex items-center gap-3">
        {/* Filtre Statut */}
        <div className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value)}
            className="bg-transparent border-none text-sm focus:outline-none cursor-pointer"
            aria-label="Filtrer par statut"
          >
            <option value="Tous">Tous ({totalPatients})</option>
            <option value="Actif">Actif</option>
            <option value="Urgent">Urgent ({urgentCount})</option>
            <option value="En attente">En attente</option>
            <option value="Clôturé">Clôturé</option>
          </select>
        </div>

        {/* Filtre Pathologie */}
        <select
          value={pathologyFilter}
          onChange={(e) => onPathologyFilterChange(e.target.value)}
          className="px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer transition-all"
          aria-label="Filtrer par pathologie"
        >
          <option value="Toutes">Toutes pathologies</option>
          {PATHOLOGIES.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

// src/features/medecin/components/PaginationControls.jsx
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function PaginationControls({
  currentPage,
  totalPages,
  startIndex,
  itemsPerPage,
  totalItems,
  onPageChange,
}) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-between px-4 py-4 border-t border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/30 rounded-lg">
      <p className="text-sm text-gray-500">
        {startIndex + 1} - {Math.min(startIndex + itemsPerPage, totalItems)} sur{' '}
        {totalItems} patients
      </p>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="p-2 rounded-lg border border-gray-200 dark:border-gray-700 disabled:opacity-40 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Page précédente"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <span className="text-sm text-gray-600 dark:text-gray-400">
          Page {currentPage} / {totalPages}
        </span>

        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="p-2 rounded-lg border border-gray-200 dark:border-gray-700 disabled:opacity-40 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          aria-label="Page suivante"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// src/features/medecin/components/PatientCard.jsx
import { motion } from 'framer-motion';
import { Eye, Edit, Trash2, Calendar } from 'lucide-react';
import { getStatusStyle, getPathologyStyle, getIaStyle } from '../utils/styleHelpers';

export function PatientCard({
  patient,
  formatDate,
  getInitials,
  onSelect,
  onEdit,
  onDelete,
}) {
  const statusStyle = getStatusStyle(patient.status);
  const pathoStyle = getPathologyStyle(patient.pathologyShort);
  const iaStyle = getIaStyle(patient.iaConcordance);
  const StatusIcon = statusStyle.icon;

  return (
    <motion.tr
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ backgroundColor: 'rgba(59, 130, 246, 0.02)' }}
      className="cursor-pointer group"
      onClick={() => onSelect(patient)}
    >
      {/* Avatar + Info */}
      <td className="px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-semibold text-sm shadow-md">
              {getInitials(patient.name)}
            </div>
            <div
              className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full ${statusStyle.dot} ring-2 ring-white dark:ring-gray-900`}
            />
          </div>
          <div>
            <p className="font-semibold text-gray-900 dark:text-white">
              {patient.name}
            </p>
            <p className="text-xs text-gray-400">
              {patient.gender} · {patient.city}
            </p>
          </div>
        </div>
      </td>

      {/* Age */}
      <td className="px-4 py-4 text-gray-600 dark:text-gray-400 font-medium">
        {patient.age} ans
      </td>

      {/* Pathologie */}
      <td className="px-4 py-4">
        <span
          className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${pathoStyle}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-current" />
          {patient.pathologyShort}
        </span>
      </td>

      {/* Concordance IA */}
      <td className="px-4 py-4">
        <div className="flex items-center gap-2">
          <div className="w-16 h-1.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 to-indigo-600"
              style={{ width: `${patient.iaConcordance}%` }}
            />
          </div>
          <span className={`text-xs font-medium ${iaStyle.text}`}>
            {patient.iaConcordance}%
          </span>
        </div>
      </td>

      {/* Dates */}
      <td className="px-4 py-4 text-sm text-gray-600 dark:text-gray-400">
        {formatDate(patient.lastVisit)}
      </td>

      <td className="px-4 py-4">
        <span className="text-sm text-amber-600 dark:text-amber-400 flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          {formatDate(patient.nextFollowUp)}
        </span>
      </td>

      {/* Statut */}
      <td className="px-4 py-4">
        <span
          className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}
        >
          <StatusIcon className="w-3 h-3" />
          {patient.status}
        </span>
      </td>

      {/* Actions */}
      <td className="px-4 py-4 text-right">
        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
            onClick={(e) => {
              e.stopPropagation();
              onSelect(patient);
            }}
            aria-label="Voir patient"
          >
            <Eye className="w-4 h-4 text-gray-500" />
          </button>
          <button
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(patient);
            }}
            aria-label="Modifier patient"
          >
            <Edit className="w-4 h-4 text-gray-500" />
          </button>
          <button
            className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            aria-label="Supprimer patient"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
          </button>
        </div>
      </td>
    </motion.tr>
  );
}
