// src/features/medecin/pages/Patients.jsx
// VERSION REFACTORISÉE - Production Ready

import { useState, useCallback, useMemo, useReducer } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Filter, Plus, ChevronLeft, ChevronRight,
  Eye, Edit, Trash2, Download, Share2, Calendar,
  Activity, FileText, X, User, Clock, AlertCircle,
  CheckCircle, Users, Stethoscope, Brain, FileCheck,
  Menu, Bell, Home, MessageCircle, FolderTree, Settings,
  Lock, Moon, Sun, ChevronDown, Circle, Image, Microscope,
  HeartPulse, Thermometer, Heart, Scale
} from 'lucide-react';

import { PATIENTS_DATA } from './data/patientsData';
import { usePatientFilters } from './hooks/usePatientFilters';
import { usePatientsStats } from './hooks/usePatientsStats';
import { useTheme } from './hooks/useTheme';
import { PatientCard } from './components/PatientCard';
import { PatientModal } from './components/PatientModal';
import { StatsCards } from './components/StatsCards';
import { FilterBar } from './components/FilterBar';
import { PatientsTable } from './components/PatientsTable';
import { PaginationControls } from './components/PaginationControls';

// ========== INITIAL STATE & REDUCER ==========
const initialState = {
  selectedPatient: null,
  isModalOpen: false,
  activeTab: 'dossier',
  editMode: false,
  editedPatient: null,
  statusDropdownOpen: false,
  sidebarOpen: false,
  currentPage: 1,
  searchTerm: '',
  statusFilter: 'Tous',
  pathologyFilter: 'Toutes',
};

function patientReducer(state, action) {
  switch (action.type) {
    case 'OPEN_MODAL':
      return {
        ...state,
        selectedPatient: action.payload,
        editedPatient: { ...action.payload },
        isModalOpen: true,
        editMode: false,
        activeTab: 'dossier',
      };
    case 'CLOSE_MODAL':
      return { ...state, isModalOpen: false, selectedPatient: null };
    case 'SET_EDIT_MODE':
      return { ...state, editMode: true, editedPatient: { ...state.selectedPatient } };
    case 'CANCEL_EDIT':
      return { ...state, editMode: false, editedPatient: null };
    case 'SAVE_EDIT':
      return { ...state, selectedPatient: state.editedPatient, editMode: false };
    case 'UPDATE_EDITED_PATIENT':
      return { ...state, editedPatient: { ...state.editedPatient, ...action.payload } };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'TOGGLE_STATUS_DROPDOWN':
      return { ...state, statusDropdownOpen: !state.statusDropdownOpen };
    case 'CHANGE_STATUS':
      return {
        ...state,
        selectedPatient: { ...state.selectedPatient, status: action.payload },
        statusDropdownOpen: false,
      };
    case 'SET_SEARCH_TERM':
      return { ...state, searchTerm: action.payload, currentPage: 1 };
    case 'SET_STATUS_FILTER':
      return { ...state, statusFilter: action.payload, currentPage: 1 };
    case 'SET_PATHOLOGY_FILTER':
      return { ...state, pathologyFilter: action.payload, currentPage: 1 };
    case 'SET_CURRENT_PAGE':
      return { ...state, currentPage: action.payload };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarOpen: !state.sidebarOpen };
    default:
      return state;
  }
}

// ========== COMPOSANT PRINCIPAL ==========
export default function Patients() {
  const [state, dispatch] = useReducer(patientReducer, initialState);
  const { theme, toggleTheme } = useTheme();
  const stats = usePatientsStats();
  const filteredPatients = usePatientFilters(
    state.searchTerm,
    state.statusFilter,
    state.pathologyFilter
  );

  // Pagination
  const itemsPerPage = 6;
  const totalPages = Math.ceil(filteredPatients.length / itemsPerPage);
  const startIndex = (state.currentPage - 1) * itemsPerPage;
  const currentPatients = filteredPatients.slice(startIndex, startIndex + itemsPerPage);

  // ========== CALLBACKS MEMOIZÉS ==========
  const handleOpenModal = useCallback(
    (patient) => dispatch({ type: 'OPEN_MODAL', payload: patient }),
    []
  );

  const handleCloseModal = useCallback(
    () => dispatch({ type: 'CLOSE_MODAL' }),
    []
  );

  const handleSetActiveTab = useCallback(
    (tab) => dispatch({ type: 'SET_ACTIVE_TAB', payload: tab }),
    []
  );

  const handleSetEditMode = useCallback(() => {
    dispatch({ type: 'SET_EDIT_MODE' });
  }, []);

  const handleSaveEdit = useCallback(() => {
    dispatch({ type: 'SAVE_EDIT' });
    // TODO: Appel API pour sauvegarder
  }, []);

  const handleCancelEdit = useCallback(
    () => dispatch({ type: 'CANCEL_EDIT' }),
    []
  );

  const handleChangeStatus = useCallback((newStatus) => {
    dispatch({ type: 'CHANGE_STATUS', payload: newStatus });
  }, []);

  const handleUpdateEditedPatient = useCallback((updates) => {
    dispatch({ type: 'UPDATE_EDITED_PATIENT', payload: updates });
  }, []);

  const handleSearchChange = useCallback((value) => {
    dispatch({ type: 'SET_SEARCH_TERM', payload: value });
  }, []);

  const handleStatusFilterChange = useCallback((value) => {
    dispatch({ type: 'SET_STATUS_FILTER', payload: value });
  }, []);

  const handlePathologyFilterChange = useCallback((value) => {
    dispatch({ type: 'SET_PATHOLOGY_FILTER', payload: value });
  }, []);

  const handlePageChange = useCallback((page) => {
    if (page >= 1 && page <= totalPages) {
      dispatch({ type: 'SET_CURRENT_PAGE', payload: page });
    }
  }, [totalPages]);

  // Actions
  const handleExportCSV = useCallback(() => {
    // TODO: Implémenter l'export
    alert('Export CSV en cours...');
  }, []);

  const handleCreatePatient = useCallback(() => {
    // TODO: Ouvrir formulaire création
    alert('Créer nouveau patient');
  }, []);

  const handleDeletePatient = useCallback(() => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce patient ?')) {
      // TODO: Appel API
      handleCloseModal();
      alert('Patient supprimé');
    }
  }, [handleCloseModal]);

  const handleShareDossier = useCallback(() => {
    // TODO: Ouvrir dialog partage
    alert('Partage du dossier');
  }, []);

  const handleExportPDF = useCallback(() => {
    // TODO: Générer PDF
    alert('Export PDF en cours...');
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800">
      <div className="flex h-screen overflow-hidden">
        {/* MAIN CONTENT */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
            {/* Header */}
            <HeaderSection
              onExportCSV={handleExportCSV}
              onCreatePatient={handleCreatePatient}
              sidebarOpen={state.sidebarOpen}
              onToggleSidebar={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
            />

            {/* KPI Stats */}
            <StatsCards stats={stats} totalPatients={Object.keys(PATIENTS_DATA).length} />

            {/* Filters */}
            <FilterBar
              searchTerm={state.searchTerm}
              statusFilter={state.statusFilter}
              pathologyFilter={state.pathologyFilter}
              totalPatients={Object.keys(PATIENTS_DATA).length}
              urgentCount={stats.urgent}
              onSearchChange={handleSearchChange}
              onStatusFilterChange={handleStatusFilterChange}
              onPathologyFilterChange={handlePathologyFilterChange}
            />

            {/* Patients Table */}
            <PatientsTable
              patients={currentPatients}
              onSelectPatient={handleOpenModal}
              onEditPatient={(patient) => {
                handleOpenModal(patient);
                handleSetEditMode();
              }}
              onDeletePatient={handleDeletePatient}
            />

            {/* Pagination */}
            {totalPages > 1 && (
              <PaginationControls
                currentPage={state.currentPage}
                totalPages={totalPages}
                startIndex={startIndex}
                itemsPerPage={itemsPerPage}
                totalItems={filteredPatients.length}
                onPageChange={handlePageChange}
              />
            )}
          </div>
        </main>

        {/* Patient Modal */}
        <PatientModal
          isOpen={state.isModalOpen}
          patient={state.selectedPatient}
          editMode={state.editMode}
          editedPatient={state.editedPatient}
          activeTab={state.activeTab}
          statusDropdownOpen={state.statusDropdownOpen}
          onClose={handleCloseModal}
          onSetActiveTab={handleSetActiveTab}
          onSetEditMode={handleSetEditMode}
          onCancelEdit={handleCancelEdit}
          onSaveEdit={handleSaveEdit}
          onUpdateEditedPatient={handleUpdateEditedPatient}
          onToggleStatusDropdown={() => dispatch({ type: 'TOGGLE_STATUS_DROPDOWN' })}
          onChangeStatus={handleChangeStatus}
          onShare={handleShareDossier}
          onExportPDF={handleExportPDF}
          onDelete={handleDeletePatient}
        />
      </div>
    </div>
  );
}

// ========== SOUS-COMPOSANTS INTÉGRÉS ==========
function HeaderSection({ onExportCSV, onCreatePatient, sidebarOpen, onToggleSidebar }) {
  return (
    <div className="relative overflow-hidden rounded-2xl p-6 sm:p-8 bg-gradient-to-r from-blue-600 to-indigo-600">
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)',
        backgroundSize: '24px 24px'
      }}></div>

      <div className="relative flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center">
          <button
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-lg bg-white/20 text-white hover:bg-white/30 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
          <h1 className="ml-4 text-2xl font-bold text-white">Mes Patients</h1>
        </div>

        <div className="flex gap-3 flex-wrap">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onExportCSV}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm text-white rounded-xl hover:bg-white/30 shadow-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm font-medium">Exporter</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onCreatePatient}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white text-blue-600 rounded-xl hover:bg-blue-50 shadow-lg font-medium transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Nouveau patient</span>
          </motion.button>
        </div>
      </div>
    </div>
  );
}
