// src/features/medecin/hooks/usePatientFilters.js
import { useMemo } from 'react';
import { PATIENTS_DATA } from '../data/patientsData';

export function usePatientFilters(searchTerm, statusFilter, pathologyFilter) {
  return useMemo(() => {
    const patientsArray = Object.values(PATIENTS_DATA);
    return patientsArray.filter((patient) => {
      const matchSearch =
        patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.pathologyShort.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.city.toLowerCase().includes(searchTerm.toLowerCase());

      const matchStatus = statusFilter === 'Tous' || patient.status === statusFilter;
      const matchPathology =
        pathologyFilter === 'Toutes' || patient.pathologyShort === pathologyFilter;

      return matchSearch && matchStatus && matchPathology;
    });
  }, [searchTerm, statusFilter, pathologyFilter]);
}

// src/features/medecin/hooks/usePatientsStats.js
import { useMemo } from 'react';
import { PATIENTS_DATA } from '../data/patientsData';

export function usePatientsStats() {
  return useMemo(() => {
    const patientsArray = Object.values(PATIENTS_DATA);
    const now = new Date();
    const thirtyDaysAgo = new Date(now.setDate(now.getDate() - 30));

    return {
      total: patientsArray.length,
      consultationsMonth: patientsArray.filter((p) => {
        const lastVisit = new Date(p.lastVisit);
        return lastVisit >= thirtyDaysAgo;
      }).length,
      urgent: patientsArray.filter((p) => p.status === 'Urgent').length,
      shared: patientsArray.filter((p) => p.shareAccess?.length > 0).length,
    };
  }, []);
}

// src/features/medecin/hooks/useTheme.js
import { useState, useEffect } from 'react';

const THEME_KEY = 'pneumoia-theme';

export function useTheme() {
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme) {
      setTheme(savedTheme);
      applyTheme(savedTheme);
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
      applyTheme('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem(THEME_KEY, newTheme);
    applyTheme(newTheme);
  };

  return { theme, toggleTheme };
}

function applyTheme(theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark');
}

// src/features/medecin/hooks/usePatientModal.js
import { useCallback } from 'react';

export function usePatientModal(dispatch) {
  const openModal = useCallback(
    (patient) => dispatch({ type: 'OPEN_MODAL', payload: patient }),
    [dispatch]
  );

  const closeModal = useCallback(
    () => dispatch({ type: 'CLOSE_MODAL' }),
    [dispatch]
  );

  const setEditMode = useCallback(
    () => dispatch({ type: 'SET_EDIT_MODE' }),
    [dispatch]
  );

  return { openModal, closeModal, setEditMode };
}

// src/features/medecin/hooks/useFormatters.js
export function useFormatters() {
  const formatDate = (date) => {
    if (!date) return '—';
    const d = new Date(date);
    return d.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const getInitials = (name) => {
    const parts = name.split(' ');
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  };

  return { formatDate, getInitials };
}
